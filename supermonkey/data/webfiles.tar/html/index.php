<!DOCTYPE html>
<?php 
$mycloud="Openwatt"; 
$url_supermonkey="/supermonkey";
$url_projects="/stats_projects/";
$url_consul_ui="http://".$_SERVER['SERVER_NAME'].":443/ui/";
$url_consul_token="/consul";
$url_consul_api="http://".$_SERVER['SERVER_NAME']."/api";
$url_gitlab="https://gitlab.forge.orange-labs.fr/National7/N7-dev";
?>
<html>
<head>
<title>SuperMonkey - <?php echo $mycloud; ?></title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="src/bootstrap.min.css">
<link rel="stylesheet" href="src/font-awesome-4.7.0/css/font-awesome.css">
<script src="src/jquery-1.11.1.js"></script>
<script src="src/bootstrap.min.js"></script>
<script language="Javascript">
function supervision(){
  var path = "supervision.php";
  $.ajax({
  	type: "POST",
        url: path,
        success: function(htmlResponse) { document.getElementById('supervision').innerHTML = htmlResponse }
  });
  setTimeout("supervision();", 2000);
}
function kill(stat){
  var path2 = "monkey-status.php";
  $.ajax({
        type: "POST",
        url: path2,
        data: 'launched=' + stat ,
        success: function(htmlResponse) { document.getElementById('monkey_status').innerHTML = htmlResponse }
  });
  setTimeout("kill();", 2000);
}
function history(){
  var path = "log.php";
  $.ajax({
        type: "POST",
        url: path,
        success: function(htmlResponse) { document.getElementById('history').innerHTML = htmlResponse }
  });
  setTimeout("history();", 2000);
}
function cloud_status(){
  var path = "clouds_status.php";
  $.ajax({
        type: "POST",
        url: path,
        success: function(htmlResponse) { document.getElementById('cloud_status').innerHTML = htmlResponse }
  });
  setTimeout("cloud_status();", 10000);
}
cloud_status();
history();
kill('no');
supervision();
</script>
</head>
<body>
<?php session_start(); ?>
<div class="container-fluid">
  <div class="col-lg-12">
  <div class="jumbotron text-center">
    <div id="title" style="margin-top: -20px; margin-bottom: 10px;">
	<h1>SuperMonkey</h1>
    	<p><?php echo $mycloud; ?></p>
    </div>
    <div  style="background-color: #fff; border: 1px solid rgb(218, 218, 218);border-radius: 6px;" id="cloud_status">
      <p class="text-primary" style="margin-top: 10px;"><i class="fa text-primary fa-spinner fa-pulse fa-fw"></i>  Chargement surveillance des Clouds...</br></p>
    </div>
  </div>
  <div id="appli">
    <div class="col-lg-6">
    <div class="panel panel-primary">
      <div class="panel-heading">Supervision des serveurs</div>
      <div class="panel-body" id="supervision" style="max-height:520px;"></div>
  </div></div>

<div class="col-offset-lg-6 col-lg-6">
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
    </div>

    <div class="collapse navbar-collapse text-center" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fa fa-heartbeat" aria-hidden="true"></i>  Health-Check Status<span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo $url_supermonkey; ?>" target="_blank"><i class="fa fa-caret-right" aria-hidden="true"></i>  Supermonkey</a></li>
<li><a href="<?php echo $url_projects; ?>" target="_blank"><i class="fa fa-caret-right" aria-hidden="true"></i>  Projects</a></li>
          </ul>
        </li>
	<li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fa fa-database" aria-hidden="true"></i>  Database Management<span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo $url_consul_ui; ?>" target="_blank"><i class="fa fa-caret-right" aria-hidden="true"></i>  Consul UI</a></li>
	    <li><a href="<?php echo $url_consul_token; ?>" target="_blank"><i class="fa fa-caret-right" aria-hidden="true"></i>  Consul Token</a></li>
	    <li><a href="<?php echo $url_consul_api; ?>" target="_blank"><i class="fa fa-caret-right" aria-hidden="true"></i>  Consul API</a></li>
          </ul>
        </li>
	<li><a href="<?php echo $url_gitlab; ?>" target="_blank"><i class="fa fa-gitlab" aria-hidden="true"></i> Gitlab</a></li>

       </div>
  </div>
</nav>

    <div class="panel panel-warning">
      <div class="panel-heading">Chaos Monkey</div>
      <div class="panel-body text-center" style="max-height: 102px;">
	  <div id="monkey_status"></div>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading">Historique</div>
      <div class="panel-body" style="max-height: 283px; overflow-y: scroll;">
          <div id="history"></div>
      </div>
    </div>
</div>

  </div>

</div>

</body>
<!-- By Gwendal ORINEL -->
</html>

