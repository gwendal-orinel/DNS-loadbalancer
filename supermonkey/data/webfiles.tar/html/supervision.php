        <?php
	 session_start();
	 $output = shell_exec('bash /var/www/html/super-check.sh');
         $srv = explode(";", $output);
         $srv_up = explode("=", $srv[1]);
         $srv_down = explode("=", $srv[0]);

        $arr_up = explode(" ", $srv_up[1]);
        foreach($arr_up as $value){
        if(($value != "") && ($value != " ")){  ?>
        <div class="alert alert-success" role="alert">
		<strong><?php echo ucfirst($value) ?></strong> - En Ligne 
	<?php if(($srv_down[1] == "") && ($_SESSION['all_cloud_status'] == "up")){ ?> <button name="button_humankill" onclick="kill('<?php echo $value ?>');"  type="button" class="btn btn-default btn-xs pull-right button_humankill" style="/* text-decoration: none; color: grey;*/" title="Régénérer l'instance"><i class="fa fa-legal" aria-hidden="true">  rebuild</i></button><?php } ?>
	</div>
        <?php } }

        $arr_down = explode(" ", $srv_down[1]);
        foreach($arr_down as $value){
        if(($value != "") && ($value != " ")){ $value;?>
        <div class="alert alert-danger" role="alert">
		<strong><?php echo ucfirst($value) ?></strong> - Hors Ligne </div>
        <?php } } ?>
