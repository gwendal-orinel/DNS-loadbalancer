<?php
session_start();

$cloudlist=shell_exec('cat settings.json | jq -r .Clouds[].name+\",\"');
$adresses=shell_exec('cat settings.json | jq -r .Clouds[].ip_public+\",\"');

$cloud=explode(",", $cloudlist);
$address=explode(",", $adresses);

$nb_cloud=count($cloud)-1;
$nb_cloud_up=0;

?><ul class="nav nav-pills nav-justified"><?php

for($i = 0; $i < $nb_cloud; ++$i){

$cloud_status = shell_exec('curl -s --connect-timeout 2 http://'.$address[$i].'/monkey-status.php  | grep cloud_status | grep up');

if($cloud_status){ $nb_cloud_up=$nb_cloud_up+1; }

if($cloud_status){ ?>
<li role="presentation"><a href="http://<?php echo $address[$i] ?>/" class="text-success" title="Aller vers <?php echo $cloud[$i] ?>"><u><?php echo $cloud[$i] ?> </u></br><i class="fa fa-check text-success fa-3x" aria-hidden="true"></i></a></li>
<?php } else { ?>
<li role="presentation"><a href="http://<?php echo $address[$i] ?>/" class="text-danger" title="Aller vers <?php echo $cloud[$i] ?>"><u><?php echo $cloud[$i] ?> </u></br><i class="fa fa-times text-danger fa-3x" aria-hidden="true"></i></a></li>
<?php } 

if($nb_cloud_up == $nb_cloud) {
$clouds_status="up";
}else{
$clouds_status="down";
}
}
$_SESSION['all_cloud_status']=$clouds_status;

?>
</ul>

