down="";
up="";

list=$(curl -s 127.0.0.1:8500/v1/agent/checks | jq -r .[].CheckID)

for node in $list; do

if [ $node != "regenerator" ]; then
status=$(curl -s 127.0.0.1:8500/v1/agent/checks | jq -r .$node.Status)

if [ $status != "passing" ]; then
down=$down' '$node;
else
up=$up' '$node;
fi

fi
done
echo "Down="$down";"
echo "Up="$up";"
down=""
up=""




