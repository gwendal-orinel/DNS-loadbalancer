<!DOCTYPE html>
<?php
session_start();

$acc1='<div class=\'col-lg-6\'><form method=\"post\" action=\"#\"><div class=\"panel panel-default\"><div class=\'panel-heading\' role=\'tab\' id=\'headingOne\'><h4 class=\'panel-title\'>';
$acc2='<button type=\"submit\" name=\"form3\" class=\"close\"><span class=\"pull-right\"><i class=\"fa fa-trash-o\" aria-hidden=\"true\"></i></span></button></h4></div><div class=\'panel-body\'>';
$acc3='</div></div></form></div>';

$_SESSION['consul_server']="checker:8500";
$mycloud=shell_exec('cat ../settings.json | jq -r .mycloud');
$admintoken=shell_exec("cat ../settings.json | jq -r .Clouds.'".$mycloud."'.admin_token");
$admintoken=rtrim($admintoken);


#creation token
if((isset($_POST['form2']))&&(isset($_POST['email_token']))&&(isset($_POST['type_token']))&&(isset($_POST['project_token']))){
  $_POST['rules_token'] = str_replace('"', '\"', $_POST['rules_token']);
 shell_exec('curl -X PUT -d \'{"name":"'.$_POST['project_token'].'", "type":"'.$_POST['type_token'].'","rules": "service \"'.$_POST['project_token'].'\" {policy=\"write\"} #client '.$_POST['email_token'].'#!client" }\' http://'.$_SESSION['consul_server'].'/v1/acl/create?token='.$admintoken );

}

#login
if((isset($_POST['form']))&&(isset($_POST['consul_token']))){
  $token_test = shell_exec('curl -s --connect-timeout 2 http://'.$_SESSION['consul_server'].'/v1/acl/list?token='.$admintoken.' | jq -r \'.[].ID\'|grep -w "'.$_POST['consul_token'].'"');
  $token_test = rtrim($token_test);
  if($token_test !== $_POST['consul_token']){ ?><div class="alert alert-danger text-center" role="alert"><strong><?php
        echo "Le serveur est injoignable ou le token est invalide"; ?> </strong></div><?php
  }else{
     $_SESSION['consul_token']=$_POST['consul_token'];
  }
}


#delete token
if((isset($_POST['form3']))&&(isset($_POST['token']))&&(isset($_POST['project_name']))){
  if(($_POST['token'] != $admintoken )&&($_POST['token'] != "anonymous")){
  shell_exec('curl -X PUT http://'.$_SESSION['consul_server'].'/v1/acl/destroy/'.$_POST['token'].'?token='.$admintoken );
  shell_exec('curl -X DELETE "http://'.$_SESSION['consul_server'].'/v1/agent/service/deregister/'.$_POST['project_name'].'?token='.$admintoken.' "');
  }
}

?>

<html>
<head>
<title>Consul Admin Status</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../src/bootstrap.min.css">
<link rel="stylesheet" href="../src/font-awesome-4.7.0/css/font-awesome.css">
<script src="../src/jquery-1.11.1.js"></script>
</head>
<body>
<div class="container-fluid">
  <div class="col-lg-12">
  <div class="jumbotron text-center">
    <div id="title" style="margin-top: -20px; margin-bottom: 10px;">
        <h1>Consul Status</h1>
        <p>Openwatt/Cloudwatt</p>
    </div>
    <div id="cloud_infos">
      <form method="post" action="/consul/index.php">
      <div class="input-group col-lg-6 col-lg-offset-3">
        <span class="input-group-addon"><i class="fa fa-key"></i></span>
        <input type="text" class="form-control" name="consul_token" placeholder="Access Token" value="<?php echo $_POST['consul_token'];?>" required="required"/>
      </div></br>
      <div class="col-lg-2 col-lg-offset-5"><input type="submit" name="form" class="form-control btn btn-primary" value="Connect"></div>
      </form>
    </div>

  </div>
  <div id="appli">
    <?php
      if(isset($_SESSION['consul_token'])){

                $leader = shell_exec('curl --connect-timeout 2 http://'.$_SESSION['consul_server'].'/v1/status/leader?token='.$SESSION['consul_token'].'|tr -d "\""');
                $peers = shell_exec('curl --connect-timeout 2 http://'.$_SESSION['consul_server'].'/v1/status/peers?token='.$SESSION['consul_token'].'|tr -d "[]\""');
                $nodes = shell_exec('curl --connect-timeout 2 http://'.$_SESSION['consul_server'].'/v1/catalog/nodes?token='.$SESSION['consul_token'].'|jq -r \'.[] | {node: .Node,address: .Address} | .node+" : "+.address+"</br>"\'');

                $check = shell_exec('curl --connect-timeout 2 http://'.$_SESSION['consul_server'].'/v1/health/state/any?token='.$SESSION['consul_token'].'|jq -r \'.[] | {node: .Node,status: .Output} | .node+" : "+.status+"</br>"\'');
                $acl = shell_exec('curl --connect-timeout 2 http://'.$_SESSION['consul_server'].'/v1/acl/list?token='.$_SESSION['consul_token'].'| jq -r \'.[] | {name: .Name,token: .ID,type: .Type,rules: .Rules,user: .user} | "'.$acc1.'"+.name+"<input type=\"hidden\" name=\"project_name\" value="+.name+">'.$acc2.'Token: "+.token+"<input type=\"hidden\" name=\"token\" value="+.token+"></br>Type: "+.type+"</br>Rules: "+.rules+"'.$acc3.'"\'');

            ?>
            <div class="col-lg-12">
                <div class="panel panel-primary">
                   <div class="panel-heading">Api Explorer</div>
                   <div class="panel-body" id="api_content">
                     <table class="table table-striped">
                        <tr><td width="150">Leader :</td><td><?php echo $leader; ?></td></tr>
                        <tr><td>Peers connected :</td><td><?php echo $nodes; ?></td></tr>
                        <tr><td>Health check :</td><td><?php echo $check; ?></td></tr>
                        <tr><td>Peers registered :</td><td><?php echo $peers; ?></td></tr>
                        <tr><td>Acl-Token:</td><td><?php $acl = str_replace('#client','</br>Client: <a name="cl_mail">',$acl); $acl = str_replace('#!client','</a>',$acl);echo $acl; if(!empty($acl)){?>
                          <div class="col-lg-6">
                            <form method="post" action="/consul/index.php">
                            <div class="panel panel-default">
                                <div class="panel-heading" role="tab" id="headingOne">
                                  <h4 class="panel-title">New Token</h4>
                                </div>
                                <div class="panel-body">
                                  <select class="form-control" name="type_token" required="required" /><option value="client" selected>Client</option><option value="management">Management</option></select>
                                   <input type="text" class="form-control" name="project_token" placeholder="Short Project Name" required="required"/>
                                   <input type="email" pattern="[a-z0-9._%+-]*[@]\orange.com" class="form-control"  name="email_token" placeholder="Email Requester @orange.com" required="required"/>
                                  <input type="submit" name="form2" class="form-control btn btn-default" value="Create">
                                </div>
                            </div>
                           </form>
                           </div><?php } ?>
                        </td></tr>
                     </table>
                   </div>
                </div>
            </div>
    <?php } ?>
  </div>
</div>
<script>
var nb_form = document.getElementsByTagName("form");
for(var i=0; i<nb_form.length; i++){
var mail = nb_form[i].getElementsByTagName("div")[2].getElementsByTagName("a")[0]
if (typeof(mail) !== 'undefined'){
   var token = nb_form[i].getElementsByTagName("div")[2].getElementsByTagName("input")[0].value
   var api_dir = nb_form[i].getElementsByTagName("div")[1].innerText
   mail.href = "mailto:"+mail.innerHTML+"?subject=N7-Access token&body=Project directory: projects/"+api_dir+"/%0AToken: "+token;
}
}

</script>
</div>
</div>
</body>
<!-- By Gwendal ORINEL -->
</html>

