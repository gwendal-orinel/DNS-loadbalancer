list=$(curl -s 127.0.0.1:8500/v1/agent/checks | jq .[].CheckID)

if [ -z $1 ]; then
srv_list=($list)
rand=$(date +%S)
cpt=0
killed=""
i=0
while [ $cpt -le $rand ]; do
killed=${srv_list[$i]}
i=$(($i+1))
cpt=$(($cpt+1))
if [ $i == "3" ]; then i=0 ;fi
done
node=$killed
else
node=$1
fi
echo "Stopping contianer " $node
curl --unix-socket /var/run/docker.sock -X POST http:/v1.24/containers/$node/stop

