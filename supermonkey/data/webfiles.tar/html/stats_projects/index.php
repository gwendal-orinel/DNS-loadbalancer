<!DOCTYPE html>
<?php
session_start();

$acc1='<div class=\"col-lg-12 box_service\"><div class=\"panel panel-default\"><div class=\'panel-heading\' role=\'tab\' id=\'headingOne\'><h4 class=\'panel-title\'>';
$acc2='</h4></div><div class=\'panel-body\'>';
$acc3='</div></div></div>';

$_SESSION['consul_server']="checker:8500";
$mycloud=shell_exec('cat ../settings.json | jq -r .mycloud');
$admintoken=shell_exec("cat ../settings.json | jq -r .Clouds.'".$mycloud."'.admin_token");
$admintoken=rtrim($admintoken);

#login
if((isset($_POST['form']))&&(isset($_POST['consul_token']))){
  $token_test = shell_exec('curl -s --connect-timeout 2 http://'.$_SESSION['consul_server'].'/v1/acl/list?token='.$admintoken.' | jq -r \'.[].ID\'|grep -w "'.$_POST['consul_token'].'"');
  $token_test = rtrim($token_test);
  if($token_test !== $_POST['consul_token']){ ?><div class="alert alert-danger text-center" role="alert"><strong><?php
        echo "Le token est invalide"; ?> </strong></div><?php
  }else{
     $_SESSION['consul_token']=$_POST['consul_token'];
  }
}


?>

<html>
<head>
<title>Services Status</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../src/bootstrap.min.css">
<link rel="stylesheet" href="../src/font-awesome-4.7.0/css/font-awesome.css">
<script src="../src/jquery-1.11.1.js"></script>
</head>
<body>
<div class="container-fluid">
  <div class="col-lg-12">
  <div class="jumbotron text-center">
    <div id="title" style="margin-top: -20px; margin-bottom: 10px;">
        <h1>Services Status</h1>
        <p><?php echo $mycloud ?></p>
    </div>
    <div id="cloud_infos">
      <form method="post" action="#">
      <div class="input-group col-lg-6 col-lg-offset-3">
        <span class="input-group-addon"><i class="fa fa-key"></i></span>
        <input type="text" class="form-control" name="consul_token" placeholder="Access Token" value="<?php echo $_POST['consul_token'];?>" required="required"/>
      </div></br>
      <div class="col-lg-2 col-lg-offset-5"><input type="submit" name="form" class="form-control btn btn-primary" value="Connect"></div>
      </form>
    </div>

  </div>
  <div id="appli">
    <?php
      if(isset($_SESSION['consul_token'])){

				$domain_url = shell_exec('curl --connect-timeout 2 http://core:8500/v1/agent/self | jq -r .Config.Domain');
				$services_list = shell_exec('curl --connect-timeout 2 http://'.$_SESSION['consul_server'].'/v1/catalog/services?token='.$_SESSION['consul_token'].'| jq -r \'to_entries | {key: .[].key} | "<block_list>'.$acc1.'Service <service_name_list>"+.key+"</service_name_list> ("+.key+".'.$domain_url.')'.$acc2.'<service_list></service_list>'.$acc3.'</block_list>"\'');
				$services_api = shell_exec('curl --connect-timeout 2 http://'.$_SESSION['consul_server'].'/v1/agent/services?token='.$_SESSION['consul_token'].'| jq -r \'.[] | {ID: .ID,Port: .Port|tostring,Service: .Service,Tags: .Tags|tostring,Address: .Address} | "<block_service>'.$acc1.'Serveur: <service_id>"+.ID+"</service_id>'.$acc2.'<service_content>Service: <service_name>"+.Service+"</service_name></br>ID: "+.ID+"</br>Address: "+.Address+"</br>Port: "+.Port+"</br>Tags: "+.Tags+"</br></br></service_content>'.$acc3.'</block_service>"\'');
				$checks_api = shell_exec('curl --connect-timeout 2 http://'.$_SESSION['consul_server'].'/v1/agent/checks?token='.$_SESSION['consul_token'].'| jq -r \'.[] | {ID: .ServiceID,Output: .Output,Notes: .Notes,Status: .Status,Node: .Node} | "<block_check>'.$acc1.'Check: <check_name>"+.ID+"</check_name>'.$acc2.'<check_content>Status: <check_status>"+.Status+"</check_status></br>Notes: "+.Notes+"</br>Output: <h6><div class=\"well well-sm\">"+.Output+"</div></h6></check_content>'.$acc3.'</block_check>"\'');
				

            ?>
            <div class="col-lg-12">

					<?php echo $services_list;  ?>
					 <?php echo $services_api;  ?>
					 <?php echo $checks_api; ?>
					 
            </div>
    <?php } ?>
  </div>
</div>
<script>
var block_list = document.getElementsByTagName("block_list"); //var objets lists
var block_service = document.getElementsByTagName("block_service"); //var objets services
var block_check = document.getElementsByTagName("block_check"); //var objets checks


for(var i=0; i<block_service.length; i++){ //on bloucle sur toutes les services
	var service_name = block_service[i].getElementsByTagName("service_name")[0].innerHTML;
	var service_id = block_service[i].getElementsByTagName("service_id")[0].innerHTML;
	
	block_service[i].getElementsByTagName("h4")[0].parentElement.style.backgroundColor = "#d9edf7"
	
	for(var z=0; z<block_check.length; z++){ //boucle check -> service
		var check_name = block_check[z].getElementsByTagName("check_name")[0].innerHTML;
		var check_status = block_check[z].getElementsByTagName("check_status")[0].innerHTML;
		
		if(check_status == "passing"){
			block_check[z].getElementsByTagName("h4")[0].parentElement.style.backgroundColor = "#dff0d8"
		}else{
			block_check[z].getElementsByTagName("h4")[0].parentElement.style.backgroundColor = "#a94442"
		}
		if(check_name == service_id){
			var service_content = block_service[i].getElementsByTagName("service_content")[0]
			block_check[z].children[0].className = "col-lg-12 box_check" //changement taille
			service_content.innerHTML = service_content.innerHTML+block_check[z].innerHTML
			block_check[z].remove()//supression ancien bloc
		}
	}
	
	for(var y=0; y<block_list.length; y++){ //bloucle  service -> liste
		var list_name = block_list[y].getElementsByTagName("service_name_list")[0].innerHTML
		if(list_name == service_name){
			var list_content = block_list[y].getElementsByTagName("service_list")[0]
			block_service[i].children[0].className = "col-lg-4 box_service" //changement taille
			list_content.innerHTML = list_content.innerHTML+block_service[i].innerHTML //ajout du service dans la liste
		}
	}
	block_service[i].remove()//supression ancien bloc
	i--
}

for(var x=0; x<block_list.length; x++){ //supression list consul (inutile)
	var list_name = block_list[x].getElementsByTagName("service_name_list")[0].innerHTML;
	if(block_list.length == "1"){ var nbservice = "1" }else{ var nbservice = block_list.length };
	if(list_name == "consul"){
		block_list[x].remove()
	}
	if(nbservice == "1"){
                alert("Le token est valide mais aucun service a ete trouve")
        }
}

</script>

</div>
</div>
</body>
<!-- By Gwendal ORINEL -->
</html>


