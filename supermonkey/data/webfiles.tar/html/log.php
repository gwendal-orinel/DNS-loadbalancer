	<?php
         $output = array_reverse( file('/consul/supermonkey_history.log') );

	 foreach ($output as $lineNumber => $lineContent)
	 {
         $log_list = explode(";", $lineContent);
         $date_log = $log_list[0];
         $status_log = $log_list[1];
	 $node_log = $log_list[2];

	if($status_log == "down")
	{  ?>
	  <div class="alert alert-danger" role="alert">
          <strong><?php echo $date_log." : " ?></strong><?php echo $node_log." - Hors ligne" ?>
          </div>
	<?php }
	if($status_log == "create")
	{ ?>
	  <div class="alert alert-success" role="alert">
          <strong><?php echo $date_log." : " ?></strong><?php echo $node_log." - A été régénéré" ?>
          </div>
	<?php }
	if($status_log == "humankill")
        { ?>
          <div class="alert alert-warning" role="alert">
          <strong><?php echo $date_log." : " ?></strong><?php echo $node_log." - Tué par un utilisateur" ?>
          </div>
        <?php }
	if($status_log == "kill")
	{ ?>
          <div class="alert alert-warning" role="alert">
          <strong><?php echo $date_log." : " ?></strong><?php echo $node_log." - Tué par le ChaosMonkey" ?>
          </div>
	<?php } }?>

