<?php
session_start();

//random kill
if((isset($_POST[launched])) && ($_POST[launched] == "yes")){
  $killed = shell_exec('/bin/bash /var/www/html/stop_CT.sh'); 
  setcookie ("killed", $killed, time() + "15"); }


//targeted kill
if((isset($_POST[launched])) && ($_POST[launched] != "yes") && ($_POST[launched] != "undefined") && ($_POST[launched] != "no")){
  $killed = shell_exec('bash /var/www/html/stop_CT.sh '.$_POST[launched].'');
  setcookie ("killed", $killed, time() + "15"); }


if (isset($_COOKIE['killed'])) {
 ?>
<div class="alert alert-danger " role="alert">
<strong><?php echo "Le serveur ".$_COOKIE['killed']."  été détruit"; ?> </strong>
</div>
<?php } else {
$output = shell_exec('bash /var/www/html/super-check.sh');
$srv = explode(";", $output);
$srv_down = explode("=", $srv[0]);

if($srv_down[1] != ""){ ?>
<input id="cloud_status" type="hidden" value="down"/>
<div class="alert alert-info" role="alert"><strong>SuperMonkey attend qu'aucun serveur ne soit Hors ligne ... </strong></div>
<?php } else { ?>
<input id="cloud_status" type="hidden" value="up"/>
<?php
if($_SESSION['all_cloud_status'] != "up"){ ?>
<div class="alert alert-info" role="alert"><strong>SuperMonkey attend que toutes les infrastructures soient entièrement opérationnelles ... </strong></div>
<?php } else { ?>
<input id="cloud_status" type="hidden" value="up"/>
<div class="alert alert-success" style=" padding:10px; margin:-10px;" role="alert"><strong>SuperMonkey est prêt </strong></div>
<button type="submit" class="btn btn-danger btn-md " style="padding:5px; margin:20px; margin-bottom:-2px" id="bouton_launch" onclick="kill('yes'); this.setAttribute('disabled', 'disabled');">  Lancer le Chaos Monkey </button>
<?php }}} ?>

